<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

#if (${NAMESPACE} && ${NAME})
/** 
 * Enum ${NAME}
 *
 * @package ${NAMESPACE}
 */
#end
enum ${NAME}#if (${BACKED_TYPE}) : ${BACKED_TYPE} #end
{

}
