<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

#if (${NAMESPACE} && ${NAME})
/** 
 * Trait ${NAME}
 *
 * @package ${NAMESPACE}
 */
#end
trait ${NAME} 
{

}