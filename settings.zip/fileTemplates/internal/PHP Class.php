<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

#if (${NAMESPACE} && ${NAME})
/** 
 * Class ${NAME}
 *
 * @package ${NAMESPACE}
 */
#end
class ${NAME} 
{
    public function __construct()
    {
    }   
}